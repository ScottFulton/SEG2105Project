package project.seg.householdchoremanager;

//Interface for button click listeners in ChoreCustomAdapter3
public interface BtnClickListener {
    public abstract void onBtnClick(int position);
}
